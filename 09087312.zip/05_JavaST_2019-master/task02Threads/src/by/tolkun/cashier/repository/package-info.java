/**
 * Provides the opportunity to store and communication with cashiers.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.cashier.repository;
