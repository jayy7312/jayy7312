/**
 * Provides the information experts classes necessary to store information
 * about {@code RestaurantCustomer}, {@code RestaurantCashier},
 * {@code RestaurantCheck}, {@code RestaurantOrder}.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.cashier.entity;
