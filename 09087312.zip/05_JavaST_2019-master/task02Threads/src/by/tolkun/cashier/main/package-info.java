/**
 * Provides run application (demonstration the work).
 *
 * @author Kirill Tolkun
 */
package by.tolkun.cashier.main;
