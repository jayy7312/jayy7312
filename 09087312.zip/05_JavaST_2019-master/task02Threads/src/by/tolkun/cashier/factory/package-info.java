/**
 * Provides the functionality for creating new objects of information expert
 * classes.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.cashier.factory;
