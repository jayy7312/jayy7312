/**
 * Provides parsing data.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.cashier.parser;
