/**
 * Provides validation input data.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.cashier.validator;
