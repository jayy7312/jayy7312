/**
 * Provides parsing using technology SAX and building objects.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.xmlparser.builder.sax;
