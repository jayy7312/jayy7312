/**
 * Provides parsing using technology JAXB (marshalling) and building objects.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.xmlparser.builder.jaxb;
