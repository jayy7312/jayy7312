/**
 * Provides building of objects.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.xmlparser.builder;
