/**
 * Provides parsing using technology DOM and building objects.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.xmlparser.builder.dom;
