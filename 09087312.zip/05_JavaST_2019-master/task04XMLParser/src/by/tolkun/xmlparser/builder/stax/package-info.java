/**
 * Provides parsing using technology StAX and building objects.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.xmlparser.builder.stax;
