/**
 * Provides printing medicines after parsing.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.xmlparser.main;
