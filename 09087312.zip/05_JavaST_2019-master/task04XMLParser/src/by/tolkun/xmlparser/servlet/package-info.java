/**
 * Provides handling http requests.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.xmlparser.servlet;
