/**
 * Provides the test for class methods from package
 * {@code xmlparser.builder.stax}.
 *
 * @author Kirill Tolkun
 */
package test.xmlparser.builder.stax;
