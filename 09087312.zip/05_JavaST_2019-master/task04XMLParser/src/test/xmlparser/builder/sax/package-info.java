/**
 * Provides the test for class methods from package
 * {@code xmlparser.builder.sax}.
 *
 * @author Kirill Tolkun
 */
package test.xmlparser.builder.sax;
