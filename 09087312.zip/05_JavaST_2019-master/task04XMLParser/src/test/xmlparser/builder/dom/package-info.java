/**
 * Provides the test for class methods from package
 * {@code xmlparser.builder.dom}.
 *
 * @author Kirill Tolkun
 */
package test.xmlparser.builder.dom;
