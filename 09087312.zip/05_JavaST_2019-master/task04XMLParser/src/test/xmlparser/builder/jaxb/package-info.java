/**
 * Provides the test for class methods from package
 * {@code xmlparser.builder.jaxb}.
 *
 * @author Kirill Tolkun
 */
package test.xmlparser.builder.jaxb;
