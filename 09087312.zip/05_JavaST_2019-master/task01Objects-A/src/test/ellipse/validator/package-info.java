/**
 * Provides the tests of class methods from package {@code ellipse.validator}.
 *
 * @author Kirill Tolkun
 */
package test.ellipse.validator;
