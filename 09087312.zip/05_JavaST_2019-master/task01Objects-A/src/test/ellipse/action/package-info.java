/**
 * Provides the tests of class methods from package {@code ellipse.action}.
 *
 * @author Kirill Tolkun
 */
package test.ellipse.action;
