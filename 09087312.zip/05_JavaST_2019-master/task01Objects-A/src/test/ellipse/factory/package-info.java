/**
 * Provides the tests for classes methods from package {@code ellipse.factory}.
 *
 * @author Kirill Tolkun
 */
package test.ellipse.factory;
