/**
 * Provides the tests for class methods from package
 * {@code ellipse.factory.geometry}.
 *
 * @author Kirill Tolkun
 */
package test.ellipse.factory.geometry;
