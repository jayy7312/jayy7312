/**
 * Provides the test for class methods from package {@code ellipse.parser}.
 *
 * @author Kirill Tolkun
 */
package test.ellipse.parser;
