/**
 * Provides the ability to validate files.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.ellipse.validator;
