/**
 * Provides the ability to parse files and use
 * {@code by.tolkun.ellipse.validator.StringValidator} to validate input
 * strings.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.ellipse.parser;
