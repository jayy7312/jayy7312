/**
 * Provides the functionality for different calculation using information expert
 * classes.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.ellipse.action;
