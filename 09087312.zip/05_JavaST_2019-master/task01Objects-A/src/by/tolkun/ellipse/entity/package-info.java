/**
 * Provides the creating experts class geometric objects and  using principles
 * of {@code by.tolkun.ellipse.factory.geometry.Geometric2DFactory}. Also
 * include {@code by.tolkun.ellipse.entity.recorder.EllipseRecorder} for
 * storing properties of geometric figures.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.ellipse.entity;
