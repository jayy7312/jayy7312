package by.tolkun.ellipse.entity.geometry;

/**
 * Command interface for all geometric objects in a square.
 *
 * @author Kirill Tolkun
 */
public interface Geometry2D {
}
