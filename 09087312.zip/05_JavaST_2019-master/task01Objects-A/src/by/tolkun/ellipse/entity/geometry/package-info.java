/**
 * Provides the information experts classes necessary to store information
 * about geometric figures.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.ellipse.entity.geometry;
