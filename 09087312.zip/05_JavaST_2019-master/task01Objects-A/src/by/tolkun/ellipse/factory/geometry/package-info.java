/**
 * Provides the creating experts classes of geometric objects using principles
 * of {@code by.tolkun.ellipse.factory.geometry.Geometric2DFactory}.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.ellipse.factory.geometry;
