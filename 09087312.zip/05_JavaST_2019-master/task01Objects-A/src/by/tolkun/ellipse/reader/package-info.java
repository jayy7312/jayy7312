/**
 * Provides the ability to read files (without parsing and validation).
 *
 * @author Kirill Tolkun
 */
package by.tolkun.ellipse.reader;
