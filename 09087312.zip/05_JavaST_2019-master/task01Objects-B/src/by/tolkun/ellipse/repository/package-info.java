/**
 * Provides the opportunity to store and communication with geometric figure.
 * Communication realized using specifications.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.ellipse.repository;
