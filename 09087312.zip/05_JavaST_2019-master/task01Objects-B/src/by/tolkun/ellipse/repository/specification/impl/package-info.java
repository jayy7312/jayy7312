/**
 * Implementations provides the building queries to
 * {@code by.tolkun.ellipse.repository.EllipseRepository}. Include find
 * specifications and sort specifications.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.ellipse.repository.specification.impl;
