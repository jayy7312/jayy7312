package by.tolkun.ellipse.repository.specification;

/**
 * Interface marker to mark specification interfaces.
 *
 * @author Kirill Tolkun
 */
public interface EllipseSpecification {

}
