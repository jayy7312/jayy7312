/**
 * Provides the interfaces for realization connection between observable object
 * and observer object.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.ellipse.observer;
