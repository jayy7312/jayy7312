/**
 * Provides the ability send event when observable class change own properties.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.ellipse.observer.event;
