/**
 * Provides the ability to store information and properties of geometric
 * figures.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.ellipse.factory.recorder;
