/**
 * Provides the opportunities to store information and properties of
 * information expert classes and follow by changes in entity classes.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.ellipse.entity.recorder;
