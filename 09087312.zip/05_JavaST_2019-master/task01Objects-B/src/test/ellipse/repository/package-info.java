/**
 * Provides the test for classes methods from package
 * {@code ellipse.repository}.
 *
 * @author Kirill Tolkun
 */
package test.ellipse.repository;
