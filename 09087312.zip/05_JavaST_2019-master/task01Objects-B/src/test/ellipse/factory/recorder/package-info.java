/**
 * Provides the tests for classes methods from package
 * {@code ellipse.factory.recorder}.
 *
 * @author Kirill Tolkun
 */
package test.ellipse.factory.recorder;
