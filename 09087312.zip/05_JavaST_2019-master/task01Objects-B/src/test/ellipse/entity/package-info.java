/**
 * Provides the tests for classes methods from package {@code ellipse.entity}.
 *
 * @author Kirill Tolkun
 */
package test.ellipse.entity;
