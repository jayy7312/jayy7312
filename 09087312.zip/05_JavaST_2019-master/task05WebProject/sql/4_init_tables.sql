USE `barbershop_db`;
INSERT INTO users (login,
                   password,
                   name,
                   surname,
                   patronymic,
                   email,
                   phone,
                   image_path,
                   role)
VALUES ("admin",
        "72phEFttR6ik1wYYLBk0iRjIr5DpWoSJTNo4A6QXY+PlfjuFnjfGguvvtUDlvKtPmUSu8jXwrRCADXR5FHkB7w==",
        "admin",
        "admin",
        "admin",
        "admin@gmail.com",
        00000000,
        "/upload/avatars/admin.jpg",
        0);