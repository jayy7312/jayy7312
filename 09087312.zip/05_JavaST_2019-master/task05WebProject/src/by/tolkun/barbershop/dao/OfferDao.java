package by.tolkun.barbershop.dao;


import by.tolkun.barbershop.entity.Offer;

public interface OfferDao extends Dao<Offer> {

}
