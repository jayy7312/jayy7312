package by.tolkun.barbershop.dao;

import by.tolkun.barbershop.entity.Employee;

public interface EmployeeDao extends Dao<Employee> {

}
