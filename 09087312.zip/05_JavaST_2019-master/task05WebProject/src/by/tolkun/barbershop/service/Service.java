package by.tolkun.barbershop.service;

public interface Service {}
