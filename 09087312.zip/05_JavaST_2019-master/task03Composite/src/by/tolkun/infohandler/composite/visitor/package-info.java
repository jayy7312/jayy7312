/**
 * Provides interaction and traversal of text component.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.infohandler.composite.visitor;
