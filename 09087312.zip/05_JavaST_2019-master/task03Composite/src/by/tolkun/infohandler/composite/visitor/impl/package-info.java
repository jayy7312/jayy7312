/**
 * Provides implementations of{@code Visitor}.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.infohandler.composite.visitor.impl;
