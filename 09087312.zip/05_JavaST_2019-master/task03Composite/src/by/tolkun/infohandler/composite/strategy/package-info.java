/**
 * Provides sort feature for {@code TextCoomponent}.
 */
package by.tolkun.infohandler.composite.strategy;
