/**
 * Provides text storing and working ability.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.infohandler.composite;
