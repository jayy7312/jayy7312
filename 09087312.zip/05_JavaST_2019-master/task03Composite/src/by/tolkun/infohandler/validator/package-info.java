/**
 * Provides ability of validation.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.infohandler.validator;
