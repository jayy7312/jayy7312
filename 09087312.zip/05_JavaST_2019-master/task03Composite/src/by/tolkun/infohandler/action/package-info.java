/**
 * Provides interaction with entity classes.
 */
package by.tolkun.infohandler.action;
