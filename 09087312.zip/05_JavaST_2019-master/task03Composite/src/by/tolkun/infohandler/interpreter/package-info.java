/**
 * Classes for interpreting bit expressions.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.infohandler.interpreter;
