/**
 * Classes for parsing.
 */
package by.tolkun.infohandler.parser;
