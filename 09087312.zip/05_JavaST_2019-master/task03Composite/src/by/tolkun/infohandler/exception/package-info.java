/**
 * Provides the handling exceptional situations.
 *
 * @author Kirill Tolkun
 */
package by.tolkun.infohandler.exception;
