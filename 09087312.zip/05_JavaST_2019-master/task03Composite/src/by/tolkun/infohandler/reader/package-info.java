/**
 * Provides the ability to read files (without parsing and validation).
 */
package by.tolkun.infohandler.reader;
