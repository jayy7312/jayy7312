/**
 * Provides the test for class methods from package {@code infohandler.parser}.
 *
 * @author Kirill Tolkun
 */
package test.infohandler.parser;
