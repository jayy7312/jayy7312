/**
 * Provides the test for class methods from package
 * {@code infohandler.composite.strategy}.
 *
 * @author Kirill Tolkun
 */
package test.infohandler.composite.strategy;
