/**
 * Provides the test for class methods from package
 * {@code infohandler.composite.visitor.impl}.
 *
 * @author Kirill Tolkun
 */
package test.infohandler.composite.visitor.impl;
