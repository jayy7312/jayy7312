/**
 * Provides the test for class methods from package
 * {@code infohandler.interpreter}.
 *
 * @author Kirill Tolkun
 */
package test.infohandler.interpreter;
